﻿
namespace Banking;

public class AccountOverdraftException : ArgumentOutOfRangeException
{
}
